/**
 * Created by manish on 6/9/17.
 */

var express = require('express');
var cors = require('cors');
var app = express();
app.use(cors());
module.exports = app;