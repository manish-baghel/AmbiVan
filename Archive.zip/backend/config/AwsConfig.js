/**
 * Created by kamal on 1/24/17.
 */
module.exports = {
    getImagePrefix: getImagePrefix
}
function getImagePrefix() {
    return 'https://s3.ap-south-1.amazonaws.com/konfinity-website-images';
}
