/**
 * Created by kamal on 1/24/17.
 */
module.exports = {
    getUrls : getUrls
};

function getUrls() {

    return {
        skill1: 'puzzle.svg',
        skill2: 'browser.svg',
        skill3: 'tree-structure.svg',
        skill4: 'database.svg'
    }
}
