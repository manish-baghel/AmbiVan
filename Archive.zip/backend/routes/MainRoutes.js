/**
 * Created by manish on 6/9/17.
 */
var express = require('express');
var mainController = require('../controllers/MainController');
var router = express.Router();
var app = require('../../ApplicationInstance');


router.route('/').get(mainController.home);
router.route('/ambulance/getAmbulance').get(mainController.getAmbulance);
router.route('/ambulance').post(mainController.ambulancePost);
router.route('/').post(mainController.postform);
router.route('/van').post(mainController.listvan);
router.route('/responder').post(mainController.formresponder);
router.route('/driver').post(mainController.formdriver);
router.route('/paramedic').post(mainController.formparamedic);
module.exports = router;
